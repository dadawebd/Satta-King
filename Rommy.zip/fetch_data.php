
<?php
    $date1 = date("Y-m-01");
    $date2 = date("Y-m-d");
    if (isset($date1) && isset($date2)) {
        $begin = new DateTime($date1);
        $end = new DateTime($date2);
        $end = $end->modify('+1 day');

        $daterange = new DatePeriod($begin, new DateInterval('P1D'), $end);
        foreach ($daterange as $date) {
            $arr[$date->format("Y-m-d")] = array();
        }
        $where = "(game_id=156 or game_id=160 or game_id=161 or game_id=163 or game_id= 164 or game_id=158 ) and  date BETWEEN '" . $date1 . "' and '" . $date2 . "'";
        $res = $db->select('games_records', 'game_id,result,date', $where);
        if (count($res) > 0) {
            foreach ($res as $key => $value) {
                $arr[$value['date']][$value['game_id']] = $value['result'];
            }
        }
        $gamewhere = ' id=156 or id=160 or id=161 or id=163 or id=164';
        $game = $db->select('games', 'id,name', $gamewhere);
    }
?>


<div class="container-fluid">
    <div class="row white mobileview">
        <?php
        $a = array();
        foreach ($arr as $key => $value) {
            array_push($a, date('m', strtotime($key)));
        }
        $ua = array_unique($a);
        foreach ($ua as $key => $distmonth) {
        ?>
        
        
      
             
 <!-- <h3 class="text-center cur_h3"><?= date('M-yy', strtotime("01-" . $distmonth . "-2020")); ?></h3>!-->
<div align="center" style="width:100%; overflow-x: scroll; margin: auto;
    background-color: #ffd800;
    font-size: 10px;
">
    <h1 style="
    color: black;
    font-size: 20px;
"><?php echo  date("F Y");?> </h1>


<table width="100%" border="0" border-color:#f46c6d cellspacing="0" cellpadding="0" class="dashed"> 
                <tbody>
                    <?php
                    if (isset($arr) && count($arr) > 0) {
                    ?>
                        <tr style="padding:20px;">
                             

                            <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;    padding: 10px;" class="date">Date</td>
                            <?php foreach ($game as $val) { ?>
                                <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name"><?= $val['name']; ?></td>
                            <?php } ?>
                        </tr>
                
                    <?php $monthcount = 0;
                        foreach ($arr as $key => $value) {
                            if ($distmonth == date('m', strtotime($key))) {
                    ?>
                            <tr>
                                <td height="29" style="background-color:#ffd80;"><span class="fon" style="font-size:10px; color:black; font-weight:bold;"><?= date('d-M-y', strtotime($key)); ?></td>
                                <?php foreach ($game as $val) { ?>
                                    <td  style="background:#ffffff;" class="sattano"><?= (isset($value[$val['id']])) ? $value[$val['id']] : '-'; ?></td>
                                <?php }
                                ?>
                            </tr>
                <?php
                            }
                        }
                    }
                ?>
                </tbody>
            </table>
            </div>
        <?php } ?>
    </div>
</div>



<?php
    $date1 = date("Y-m-01");
    $date2 = date("Y-m-d");
    if (isset($date1) && isset($date2)) {
        $begin = new DateTime($date1);
        $end = new DateTime($date2);
        $end = $end->modify('+1 day');

        $daterange = new DatePeriod($begin, new DateInterval('P1D'), $end);
        foreach ($daterange as $date) {
            $arr[$date->format("Y-m-d")] = array();
        }
        $where = "(game_id=157 or game_id=159 or game_id=162 or game_id=181) and  date BETWEEN '" . $date1 . "' and '" . $date2 . "'";
        $res = $db->select('games_records', 'game_id,result,date', $where);
        if (count($res) > 0) {
            foreach ($res as $key => $value) {
                $arr[$value['date']][$value['game_id']] = $value['result'];
            }
        }
        $gamewhere = ' id=157 or id=159 or id=162 or id=181';
        $game = $db->select('games', 'id,name', $gamewhere);
    }
?>


<div class="container-fluid">
    <div class="row white mobileview">
        <?php
        $a = array();
        foreach ($arr as $key => $value) {
            array_push($a, date('m', strtotime($key)));
        }
        $ua = array_unique($a);
        foreach ($ua as $key => $distmonth) {
        ?>
        
        
      
             
 <!-- <h3 class="text-center cur_h3"><?= date('M-yy', strtotime("01-" . $distmonth . "-2020")); ?></h3>!-->
<div align="center" style="width:100%; overflow-x: scroll; margin: auto;
    background-color: #ffd800;
    font-size: 10px;
">
    <h1 style="
    color: black;
    font-size: 20px;
"><?php echo  date("F Y");?> </h1>


<table width="100%" border="0" border-color:#f46c6d cellspacing="0" cellpadding="0" class="dashed"> 
                <tbody>
                    <?php
                    if (isset($arr) && count($arr) > 0) {
                    ?>
                        <tr style="padding:20px;">
                             

                            <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;    padding: 10px;" class="date">Date</td>
                            <?php foreach ($game as $val) { ?>
                                <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name"><?= $val['name']; ?></td>
                            <?php } ?>
                        </tr>
                
                    <?php $monthcount = 0;
                        foreach ($arr as $key => $value) {
                            if ($distmonth == date('m', strtotime($key))) {
                    ?>
                            <tr>
                                <td height="29" style="background-color:#ffd80;"><span class="fon" style="font-size:10px; color:black; font-weight:bold;"><?= date('d-M-y', strtotime($key)); ?></td>
                                <?php foreach ($game as $val) { ?>
                                    <td  style="background:#ffffff;" class="sattano"><?= (isset($value[$val['id']])) ? $value[$val['id']] : '-'; ?></td>
                                <?php }
                                ?>
                            </tr>
                <?php
                            }
                        }
                    }
                ?>
                </tbody>
            </table>
            </div>
        <?php } ?>
    </div>
</div>





<?php
    $date1 = date("Y-m-01");
    $date2 = date("Y-m-d");
    if (isset($date1) && isset($date2)) {
        $begin = new DateTime($date1);
        $end = new DateTime($date2);
        $end = $end->modify('+1 day');

        $daterange = new DatePeriod($begin, new DateInterval('P1D'), $end);
        foreach ($daterange as $date) {
            $arr[$date->format("Y-m-d")] = array();
        }
        $where = "(game_id=165 or game_id=166 or game_id=167 or game_id=168 or game_id=183 or game_id=184 or game_id=185 or game_id=1186) and  date BETWEEN '" . $date1 . "' and '" . $date2 . "'";
        $res = $db->select('games_records', 'game_id,result,date', $where);
        if (count($res) > 0) {
            foreach ($res as $key => $value) {
                $arr[$value['date']][$value['game_id']] = $value['result'];
            }
        }
        $gamewhere = ' id=165 or id=166 or id=167  or id=168  or id=183 or id=184 or id=185 or id=186';
        $game = $db->select('games', 'id,name', $gamewhere);
    }
?>


<div class="container-fluid">
    <div class="row white mobileview">
        <?php
        $a = array();
        foreach ($arr as $key => $value) {
            array_push($a, date('m', strtotime($key)));
        }
        $ua = array_unique($a);
        foreach ($ua as $key => $distmonth) {
        ?>
        
        
      
             
 <!-- <h3 class="text-center cur_h3"><?= date('M-yy', strtotime("01-" . $distmonth . "-2020")); ?></h3>!-->
<div align="center" style="width:100%; overflow-x: scroll; margin: auto;
    background-color: #ffd800;
    font-size: 10px;
">
    <h1 style="
    color: black;
    font-size: 20px;
"><?php echo  date("F Y");?> </h1>


<table width="100%" border="0" border-color:#f46c6d cellspacing="0" cellpadding="0" class="dashed"> 
                <tbody>
                    <?php
                    if (isset($arr) && count($arr) > 0) {
                    ?>
                        <tr style="padding:20px;">
                             

                            <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;    padding: 10px;" class="date">Date</td>
                            <?php foreach ($game as $val) { ?>
                                <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name"><?= $val['name']; ?></td>
                            <?php } ?>
                        </tr>
                
                    <?php $monthcount = 0;
                        foreach ($arr as $key => $value) {
                            if ($distmonth == date('m', strtotime($key))) {
                    ?>
                            <tr>
                                <td height="29" style="background-color:#ffd80;"><span class="fon" style="font-size:10px; color:black; font-weight:bold;"><?= date('d-M-y', strtotime($key)); ?></td>
                                <?php foreach ($game as $val) { ?>
                                    <td  style="background:#ffffff;" class="sattano"><?= (isset($value[$val['id']])) ? $value[$val['id']] : '-'; ?></td>
                                <?php }
                                ?>
                            </tr>
                <?php
                            }
                        }
                    }
                ?>
                </tbody>
            </table>
            </div>
        <?php } ?>
    </div>
</div>






<?php
    $date1 = date("Y-m-01");
    $date2 = date("Y-m-d");
    if (isset($date1) && isset($date2)) {
        $begin = new DateTime($date1);
        $end = new DateTime($date2);
        $end = $end->modify('+1 day');

        $daterange = new DatePeriod($begin, new DateInterval('P1D'), $end);
        foreach ($daterange as $date) {
            $arr[$date->format("Y-m-d")] = array();
        }
        $where = "(game_id=170 or game_id=172 or game_id=174 or game_id=175 or game_id=169) and  date BETWEEN '" . $date1 . "' and '" . $date2 . "'";
        $res = $db->select('games_records', 'game_id,result,date', $where);
        if (count($res) > 0) {
            foreach ($res as $key => $value) {
                $arr[$value['date']][$value['game_id']] = $value['result'];
            }
        }
        $gamewhere = ' id=170 or id=172 or id=174 or id=175  or id=169';
        $game = $db->select('games', 'id,name', $gamewhere);
    }
?>


<div class="container-fluid">
    <div class="row white mobileview">
        <?php
        $a = array();
        foreach ($arr as $key => $value) {
            array_push($a, date('m', strtotime($key)));
        }
        $ua = array_unique($a);
        foreach ($ua as $key => $distmonth) {
        ?>
        
        
      
             
 <!-- <h3 class="text-center cur_h3"><?= date('M-yy', strtotime("01-" . $distmonth . "-2020")); ?></h3>!-->
<div align="center" style="width:100%; overflow-x: scroll; margin: auto;
    background-color: #ffd800;
    font-size: 10px;
">
    <h1 style="
    color: black;
    font-size: 20px;
"><?php echo  date("F Y");?> </h1>


<table width="100%" border="0" border-color:#f46c6d cellspacing="0" cellpadding="0" class="dashed"> 
                <tbody>
                    <?php
                    if (isset($arr) && count($arr) > 0) {
                    ?>
                        <tr style="padding:20px;">
                             

                            <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;    padding: 10px;" class="date">Date</td>
                            <?php foreach ($game as $val) { ?>
                                <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name"><?= $val['name']; ?></td>
                            <?php } ?>
                        </tr>
                
                    <?php $monthcount = 0;
                        foreach ($arr as $key => $value) {
                            if ($distmonth == date('m', strtotime($key))) {
                    ?>
                            <tr>
                                <td height="29" style="background-color:#ffd80;"><span class="fon" style="font-size:10px; color:black; font-weight:bold;"><?= date('d-M-y', strtotime($key)); ?></td>
                                <?php foreach ($game as $val) { ?>
                                    <td  style="background:#ffffff;" class="sattano"><?= (isset($value[$val['id']])) ? $value[$val['id']] : '-'; ?></td>
                                <?php }
                                ?>
                            </tr>
                <?php
                            }
                        }
                    }
                ?>
                </tbody>
            </table>
            </div>
        <?php } ?>
    </div>
</div>


 

 


 

 

 


 