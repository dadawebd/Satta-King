<?php session_start();
include_once('includes/config.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
 
      include_once 'config.php';
 include_once 'admin/dbcon.php';
$con = new DB_con();

$id = (isset($_GET['group_record'])) ? intval($_GET['group_record']) : '';
if (isset($_GET["mode"]) && $_GET["mode"] == "delete") {
    if ($id > 0) {
        $res = $con->delete('games_records', 'id=' . $id);
        if ($res) {
            $_SESSION["msg"] = "Successfully deleted.";
        } else {
            $_SESSION["msg"] = "Not deleted.Please Try Again";
        }
    }
}
if (isset($_POST['btnsubmit'])) {
    unset($_POST['btnsubmit']);
    if ($id <= 0) {
        $_POST['date'] = date("Y-m-d", strtotime($_POST['date']));
        $where = "game_id = " . $_POST['game_id'] . " and date = '" . $_POST['date'] . "'";
        $check = $con->select('games_records', '*', $where);
        if (count($check) > 0) {
            $_SESSION["msg"] = "Record already exists for this Game and Date";
        } else {
            $res = $con->insert('games_records', $_POST);
            $_SESSION["msg"] = "Successfully updated.";
            header("Location:AddResult.php");
            exit;
        }
    } else {
        $_POST['date'] = date("Y-m-d", strtotime($_POST['date']));
        $where = "game_id = " . $_POST['game_id'] . " and date = '" . $_POST['date'] . "'  and id <> $id";
        $check = $con->select('games_records', '*', $where);
        if (count($check) > 0) {
            $_SESSION["msg"] = "Record already exists for this Game and Date";
        } else {
            $where = 'id=' . $id;
            unset($_POST['menuno']);
            $res = $con->update('games_records', $_POST, $where);
            if ($res) {
                $_SESSION["msg"] = "Successfully updated.";
            } else {
                $_SESSION["msg"] = "Updation Failed Please Try Again";
            }
        }
        header("Location:AddResult.php");
        exit;
    }
}

if (isset($_REQUEST['group_record'])) {
    $id = $_REQUEST['group_record'];
    $where = "id = $id";
    $r = $con->select('games_records', '*', $where);
    $ret = $r[0];
}


$active = 'game_records';
$datepicker = 'true';
  
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title> Registration and Login System</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
 

    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        
                      <h1>Select Game</h1>
                          <form method="post" action="AddResult.php<?php echo (isset($id)) ? '?group_record=' . $id : '' ?>" id="form">
        <p style="color:#F00;" id="mesg">
            <?php
            echo (isset($_SESSION["msg"])) ? $_SESSION["msg"] : '';
            unset($_SESSION["msg"]);
            ?>
        </p>
        <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">Game Name</label>
            <div class="col-sm-9">
                <select class="form-control" id="game_id" name="game_id" required="required">
                    <option value="">Select Game</option>
                    <?php
                    $userid=$_SESSION['id'];
                     $where = "id = $userid";
                    $arr = $con->select('games', 'id,name',$where);
                    foreach ($arr as $key => $value) {
                        $sel = '';
                        if (isset($_REQUEST['game'])) {
                            if ($value['id'] === $_REQUEST['game']) {
                                $sel = 'selected="selected"';
                            }
                        }
                        if (isset($ret['game_id'])) {
                            if ($value['id'] === $ret['game_id']) {
                                $sel = 'selected="selected"';
                            }
                        }
                        ?>
                        <option value="<?= $value['id']; ?>" <?php echo (isset($sel)) ? $sel : ''; ?>><?= $value['name']; ?></option>
                    <?php }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="example-search-input" class="col-sm-3 col-form-label">Result</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo (isset($ret['result'])) ? $ret['result'] : ''; ?>" id="result" name="result" placeholder="" required="required"/>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3">Date</label>
            <div class="col-sm-9">
                <input class="form-control" type="date" value="<?php echo (isset($ret['date'])) ? date("d-m-Y", strtotime($ret['date'])) : ''; ?>" id="date" name="date" placeholder="" required="required" autocomplete="off"/>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-10 col-sm-offset-10">
                <button type="submit" class="btn btn-primary" name="btnsubmit" id="save" onclick="check();">Save</button>
            </div>
        </div>
    </form>
      
                    </div>
                </main>
          <?php include('includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
