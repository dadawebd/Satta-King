<?php
define('DB_SERVER','localhost');
 
define('DB_USER','u593602035_abcking');
define('DB_PASS' ,'School@1234admin');
define('DB_NAME', 'u593602035_abcsatta');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }

?>



 
 
