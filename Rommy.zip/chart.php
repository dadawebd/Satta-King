 <?php
 date_default_timezone_set('Asia/Calcutta');
 
  require_once('config.php');
  
 ?>
 
  <?php

$ids=$_GET['id'];
         include 'admin/db.php';
         $sql = "Select * from games WHERE id='$ids'";
       foreach ($dbh->query($sql) as $row)
         ?>
<!DOCTYPE html>
<html lang="en-US">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">



<meta name=viewport content="width=device-width, initial-scale=1.0" />
<title><?php echo $row['1'];?> || supersultansatta</title>
<meta name="description" content=", Disawar Satta result, Satta king Disawar result, Disawar record chart 2020, Disawar chart 2020, Satta king Disawar chart 2019, Desawar Satta record chart 2020, Disawar game record charts 2020,Desawar result, disawar satta record " />
<meta name="keywords" content="Disawar result, Desawar Satta result, Satta king Disawar result, Desawar record chart 2020, Desawar chart 2020, Satta king Desawar chart 2020, Desawar game record chart 2019, Disawar Satta record chart 2020, disawar satta record " />
<link rel="icon" href="favicon.png" type="image/gif" sizes="16x16">
<link href="style.css" rel="stylesheet" type="text/css">
 
 <style> .navbar a {
    font-size: 15px;
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 5px;
    border: 2px solid black;
    border-radius: 10px;
   background-image: linear-gradient(to right, #77A1D3 0%, #79CBCA  51%, #77A1D3  100%);
    font-weight: bold;
}</style>
</head>
<body>
 
<div style=" background:#00d0ff; font-family: helvetica neue,Helvetica,Arial,sans-serif; font-size:14px; ">
<h1 class="my-4" align="center" ; id="1-Live">👑<?php echo $row['1'];?> 2021👑</h1>
</div>


<?php
$sql=" SELECT id,Date,jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec1 FROM desawar2020 ORDER BY Date ASC";
$results_per_page=50;
$re=mysqli_query($con,$sql);
$number_of_results=mysqli_num_rows($re);
$number_of_pages=ceil($number_of_results/$results_per_page);
if(!isset($_GET['del']))
{
	$del=1;

}
else
{
	$del=$_GET['del'];

}
$this_page_first_result=($del-1)*$results_per_page;
$sql="SELECT id,Date,jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec1 FROM desawar2020 ORDER BY Date ASC LIMIT ". $this_page_first_result .','. $results_per_page;
$re=mysqli_query($con,$sql);

 
   

 
?>



	      <?php 
	      
	      $ids=$_GET['id'];
$sql="SELECT result,date  FROM games_records Where game_id='$ids' ";
$res=mysqli_query($conn,$sql);
 
 
?>

<div class="table-result">
<div style="width:100%; overflow-x: scroll; margin: auto">
<table class="tab">
               
                    <tr class="tr0">
                        <th>Date</th>
                        <th>Jan</th>
                        <th>Feb</th>
                        <th>Mar</th>
                        <th>Apr</th>
                        <th>May</th>
                        <th>Jun</th>
                        <th>Jul</th>
                        <th>Aug</th>
                        <th>Sep</th>
                        <th>Oct</th>
                        <th>Nov</th>
                        <th>Dec</th>
                    </tr>
                
                <tbody>
                    <?php
                    for ($i = 1; $i < 32; $i++) { ?>
                        <tr>
                            <td  class='td0'><?php echo $i; ?></td>
                            <?php
                            for ($j = 1; $j < 13; $j++) {
                                $today_date = date("Y-m-d", strtotime("2021-$j-$i"));
                            ?>
                                <td class="result">
                                    <?php

                                    foreach ($res as $key => $val) {
                                        if (date("Y-m-d", strtotime($val['date'])) == $today_date) {
                                            if ("2020-$j-$i" != '2020-2-30' && "2020-$j-$i" != '2020-2-31') {

                                                echo $val['result'];
                                            }
                                        }
                                    }

                                    ?>
                                </td>
                            <?php }
                            ?>
                        </tr>
                    <?php }
                    ?>
                </tbody>
            </table>
</div>
</div>
 
<div class="navbar">
<div class="link1">
<a href="index.php">Home</a>
</div><div class="link2">
<a href="Disclaimer.php">Disclaimer</a>
</div>
<div class="link3">
<a href="about.php">About Us</a>
</div>
<div class="link3">
<a href="PrivacyPolicy.php">Privacy Policy</a>
</div><div class="link4">
<a href="Contactus.php">Contact Us</a>
</div> 
</div>
<br>
<center><div style="color:white;">Copyright © sattakingdiswar.in</div></center>
</body>
</html>