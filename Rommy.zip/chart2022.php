
 <?php
  date_default_timezone_set('Asia/Calcutta');
 require_once('includes/config.php');
 date_default_timezone_set('Asia/Calcutta');
 require_once('admin/dbcon.php');
  require_once('admin/db1.php');
  
  
  
    include_once 'config.php';
  $db = new DB_con();
    
 ?>
 
 
 

<html>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head>
    
    

      <?php

$ids=$_GET['id'];
         include 'admin/db.php';
         $sql = "Select * from games WHERE id='$ids'";
       foreach ($dbh->query($sql) as $row)
         ?>

 <title><?php echo $row['1'];?> Satta king 2021  SATTAA-KING-FAST || सट्टा किंग | Sattaking | Satta news | Satta result| Gali result </title>
 
 
<?php
$sql=" SELECT id,contents FROM keywords";

mysqli_set_charset($con,'utf8');
$re=mysqli_query($con,$sql);
if(mysqli_num_rows($re)>0)
{
    while($row=mysqli_fetch_assoc($re))
    {  
        $contents1=$row['contents'];
    ;
 
     
         
        
    }
    
}
else
{
    echo " Result";
}


?>
<meta name="description" content="<?php echo $contents1; ?>">
<meta name="keywords" content="<?php echo $contents1; ?>" />
<meta name="author" content="satta king">
<link rel="canonical" href="https://sattaa-king-fast.com/" />
<link rel="alternate" href="https://sattaa-king-fast.com/" hreflang="en-in" />
<meta name="robots" content="index, follow, all">
<meta name="googlebot" content="index, follow, all">
<meta name="bingbot" content="index, follow, all">
<meta name="rating" content="General">
<meta name="revisit-after" content="daily">
<meta name="robots" content="noodp, noydir" />
<meta name="copyright" content="© 2020. Copyrighthttps://sattaa-king-fast.com/" />
<meta name="distribution" content="Global">
<meta property="og:site_name" content="Satta king | सट्टा किंग | Sattaking | Satta news | Satta result| Gali result | satta king online https://sattaa-king-fast.com/.in">
<meta property="og:title" content="Satta king | सट्टा किंग | Sattaking | Satta news | Satta result| Gali result" />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://sattaa-king-fast.com/" />
<meta property="og:description" content="satta king, sattaking, satta news, सट्टा किंग  ,satta king online, satta king up, satta king darabar, satta king bazar, satta result, satta record, satta king result, satta king record, satta king dl, satta king leak, satta king number, satta live result" />
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">


	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <!-- css11 -->
  
<link href="css1/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css1/animate.css" rel="stylesheet" />
    <link href="css1/background.css" rel="stylesheet">
    <link href="css1/style1.css?id=1" rel="stylesheet">
 <link href="css1/style2.css" rel="stylesheet">
<style>


.td0 { background-color:#ffd800; padding-top:3px; padding-bottom:3px }

.tr0 { color:#000000; background-color: #666633; }
.tr1 { background-color:#FFFFFF;color:#000000; }
.tr2 { background-color:#FFFFFF;color:#000000; }
.blink-result{
	animation:blinkingText 0.8s infinite;
}
@keyframes blinkingText{
	50%{ color: #2AF714	}
	100%{ color: #fff	}
}
.padding_10 {
    background-color: white;
    font-weight: 400;
    padding: 0px 20px 0px;
}
.iner {
    background-color: #ffd800;
    color: white;
    border-width: 2px;
    border-color: #ffd800;
    border-style: inset;
    margin-top: 0px;
    margin-bottom: 0px;
    margin-left: 0;
    margin-right: 0px;
    padding-top: 0px;
    padding-bottom: 0px;
    padding-left: 0px;
    padding-right: 0px;
    font-weight: bold;
    text-decoration: none;
    font-size: 16px;
    font-style: italic;
    border-radius: 1px;
}
.satta-matka {
    background-color: #FF6600;
    color: white;
    border-width: 3px;
    border-color: yellow;
    border-style: inset;
    margin-top: 1px;
    margin-bottom: 1px;
    margin-left: 0;
    margin-right: 0;
    padding-top: 6px;
    padding-bottom: 6px;
    padding-left: 2px;
    padding-right: 2px;
    font-weight: bold;
    text-decoration: none;
    font-size: 12px;
    font-style: italic;
    text-shadow: 1px 1px black;
    border-radius: 1px;
}
.satta-king-cloud-content {
    background-color: #fff;
    color: #000;
    font-weight: 700;
    font-style: bold;
    font-size: large;
    text-decoration: none;
    border-width: 3px;
    border-color: #0008ff;
    border-style: outset;
    margin: 3px;
    padding: 10px;
    border-radius: 10px;
    text-align: center;
}


.satta-king-results-tab td {
    padding: 8px 5px;
    text-align: center;
    background-color: black;
    border: 2px solid #ffa400;
}
</style>



</head>
<body>
    

    


<section>
<table class="satta-king-results-tab">
<tbody><tr><td width="14%">
<a title="satta king" href="index.php">HOME</a>
</td>
<td width="30%">
<a href="/">SATTA CHART</a>
</td>
<td width="27%">
<a href="/">SATTA RECORD</a>
</td>
<td width="27%"><a href="/">SATTA KING</a>
</td>
</tr></tbody></table>
</section>
<div class="iner" style="color:black" align="center"> <font size="3">दुनिया की सर्वश्रेष्ठ सट्टा मटका बेवसाइट</font><br> <span style="font-size:small">     
<h1 style="color:Red"><strong><em>
<bdo dir="ltr"><i><span style="background-color: #003399">
    
  
 <font color="white">SATTAA-KING-FAST</font></span></i></bdo></em></strong></h1><i> </i></span>
 <div style="background-color: black"><marquee>
 <font color="white">This is official site of Satta King: Don't Go for Fake Websites
</font>
 </marquee>
 	<a href=""><img src="tele.png" style="width:300px;"></a>
 	<br>
 	<br>
 </div>
 
</div>




 
		


	      <?php 
	      
	      $ids=$_GET['id'];
$sql="SELECT result,date  FROM games_records Where game_id='$ids' ";
$res=mysqli_query($conn,$sql);
 
 
?>


<style>
.dashed tr td{ text-align: center;
border:solid 1px black;}

.date,.name { 
   
}

.sattano{
    color:purple;
    font-size: 20px;
}
/* On screens that are 992px or less, set the background color to blue */


</style>
<div class="table-result">
<div align="center" style="width:100%; overflow-x: scroll; margin: auto;
    background-color: brown;
    font-size: 10px;
">
<!--    <h1 style="-->
<!--    color: white;-->
<!--    font-size: 20px;-->
<!--"><?php echo $row['1'];?> 2022</h1>-->
<table width="100%" border="0" border-color:#f46c6d cellspacing="0" cellpadding="0" class="dashed">
               <tbody>
                    <tr >
                        <td style="padding: 10px;border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="date">Date</th>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Jan</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Feb</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Mar</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Apr</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">May</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Jun</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Jul</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Aug</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Sep</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Oct</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Nov</td>
                        <td style=" border-color:#000; background-color:#ffd800; color:black; font-size:10px; font-weight:bold;" class="name">Dec</td>
                    </tr>
                
                
                    <?php
                    for ($i = 1; $i < 32; $i++) { ?>
                        <tr>
 
                            
                            <td height="29" style="background-color:#ffd800;"><span class="fon" style="font-size:10px; color:black; font-weight:bold;"><?php echo $i; ?></span></td>
                            <?php
                            for ($j = 1; $j < 13; $j++) {
                                $today_date = date("Y-m-d", strtotime("2022-$j-$i"));
                            ?>
                                <td style="background:#ffffff;" class="sattano">
                                    <?php

                                    foreach ($res as $key => $val) {
                                        if (date("Y-m-d", strtotime($val['date'])) == $today_date) {
                                            if ("2020-$j-$i" != '2020-2-30' && "2020-$j-$i" != '2020-2-31') {

                                                echo $val['result'];
                                            }
                                        }
                                    }

                                    ?>
                                </td>
                            <?php }
                            ?>
                        </tr>
                    <?php }
                    ?>
                </tbody>
            </table>
</div>
</div>





 






<footer>
<div class="col-md-12 satta-26" style="background-color:#ffd800;    padding: 5px;">
<p style="text-align:center; color:black;">© (2019-2022) <a href="#" style="color:black;">sattaa-king-fast.com</a><br>
Sattanews-king Company Pvt. Ltd.<br>
All Rights Reserved.
</p>
</div>
</footer>

 <a style="position:fixed; bottom:20px;right:8px;">&nbsp;<input style="border:#2473c3 1px solid; background:#2d87e2; color:#fff; height:auto; padding:8px; font-weight:bold;" id="Refresh" name="Refresh" value="Refresh" type="submit" onclick="window.location.reload()">&nbsp;</a>
   

</body>
</html>


 