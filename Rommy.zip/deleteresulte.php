<?php
$con1=new mysqli('localhost', 'sbsattak_userdel', 'Admin@123','sbsattak_dtdelhi');

$id=$_GET['id'];

$data=$con1->query("delete  from games_records where id=$id");

if($data)
{
    header('location:EditResult.php');
    
}

else{
     echo "<script>alert('Not Delete');</script>";
    
}


?>