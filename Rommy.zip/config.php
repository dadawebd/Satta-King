<?php
// $conn = mysqli_connect('localhost', 'root', '');
$conn = mysqli_connect('localhost', 'u593602035_abcking', 'School@1234admin');
if (!$conn) {
    die('Could not connect: ' . mysqli_error());
}
mysqli_select_db($conn, "u593602035_abcsatta")or die("select" . mysqli_error());
// mysqli_select_db($conn, "sattakingonlinein")or die("select" . mysqli_error());
?> 
 