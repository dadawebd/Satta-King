<?php

$dbh = new PDO('mysql:host=localhost;dbname=u593602035_abcsatta', 'u593602035_abcking', 'School@1234admin');
//$dbh = new PDO('mysql:host=localhost;dbname=educate', 'root', '');
?> 
