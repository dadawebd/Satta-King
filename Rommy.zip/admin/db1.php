<?php 
$con=mysqli_connect('localhost','u593602035_abcking','School@1234admin','u593602035_abcsatta'); if(!$con) { echo "not connect database"; } 
$db1=mysqli_connect('localhost','u593602035_abcking','School@1234admin','u593602035_abcsatta'); if(!$db1) { echo "not connect database"; } 
?>

 