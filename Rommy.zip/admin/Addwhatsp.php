<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
  if(isset($_POST['add_result']))
 
 {
           
 
 
     $background=$_POST['backgroundcolor'];
    $wtsnumber=$_POST['wtsnumber'];
     $content=$_POST['content'];
    
   
    
  

  $sql="INSERT INTO addwtssection(background,wtsnumber,contents) VALUES('$background','$wtsnumber','$content')";
  
   mysqli_set_charset($con,'utf8mb4');
    $res=mysqli_query($con,$sql);
     mysqli_set_charset($con,'utf8mb4');
    if($res)
    {
        $msg="successfully Add your Data";
    }
    else
    {
        $error="no";
    }

 
     
     
 }
 
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        	<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
        <title>Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
 

    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        

                        <h1 class="mt-4">Section</h1>
                        <div class="card mb-4">
                            
                            			    
			    
			    
			     <?php
			     
 
$sql=" SELECT id,contents FROM keywords";
mysqli_set_charset($con,'utf8');
$res=mysqli_query($con,$sql);
 
if(mysqli_num_rows($res)>0)
{
    while ($row=mysqli_fetch_assoc($res))
     {
           
      
        
        
         $contents =$row['contents'];
        
        
        
        
    
        
        
        
        
    }
    
    
}

 
 
   

 
?>
                      <form role="form" method="post">
                       <?php 
                     if($error)
                        {
                        ?>
                        <div class="errorWrap"><strong>ERROR</strong>:
                            <?php echo $error; ?> 
                        </div>
                      <?php 
                      } 
                else if($msg)
                     {
                    ?>
                    <div class="succWrap"><strong>SUCCESS</strong>:
                        <?php echo $msg; ?> 
                        </div>
                    <?php 
                }
                ?>
	
                    	<div class="row">
						 	<div class="col-md-3">		
								<div class="form-group">
									<label>Background Color</label>
									<input type="text" class="form-control" name="backgroundcolor">
								</div>
						</div>
	  						
					 
			
								
    		
						<!--<div class="col-md-3">		-->
						<!--		<div class="form-group">-->
						<!--			<label>Whatsup number</label>-->
						<!--			<input type="text" class="form-control" name="wtsnumber">-->
						<!--		</div>-->
						<!--</div>-->
						
						 
						 
						 
						 
						<div class="col-md-9">		
								<div class="form-group">
									<label>Content</label>
								
                                           
                                            <textarea name="content" cols="5" rows="10"><?php echo $row['content'];?></textarea><br>   
                <script>
                        CKEDITOR.replace( 'content' );
                </script>
                
								</div>
						</div>
						 
						 
	  						
	  						
	
						</div>
					 
						<br><br>
						<div class="col-md-4">										
								<div class="form-group has-success">
									<button type="submit" class="btn btn-primary btn-block"  name="add_result" style="font-weight: bold;">ADD</button>
								</div>
								
								
						</div>
						</form>
						
    
                   
					    </div>


                    </div>
                </main>
          <?php include('../includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
