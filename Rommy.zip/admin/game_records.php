<?php 
date_default_timezone_set('Asia/Calcutta');
session_start();
 
ini_set('display_errors', 1);
error_reporting(E_ERROR);


 
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
  
    include_once '..//config.php';
 include_once 'dbcon.php';
$con = new DB_con();

$id = (isset($_GET['group_record'])) ? intval($_GET['group_record']) : '';
if (isset($_GET["mode"]) && $_GET["mode"] == "delete") {
    if ($id > 0) {
        $res = $con->delete('games_records', 'id=' . $id);
        if ($res) {
            $_SESSION["msg"] = "Successfully deleted.";
        } else {
            $_SESSION["msg"] = "Not deleted.Please Try Again";
        }
    }
}
if (isset($_POST['btnsubmit'])) {
    unset($_POST['btnsubmit']);
    if ($id <= 0) {
        $_POST['date'] = date("Y-m-d", strtotime($_POST['date']));
        $where = "game_id = " . $_POST['game_id'] . " and date = '" . $_POST['date'] . "'";
        $check = $con->select('games_records', '*', $where);
        if (count($check) > 0) {
            $_SESSION["msg"] = "Record already exists for this Game and Date";
        } else {
            $res = $con->insert('games_records', $_POST);
            $_SESSION["msg"] = "Successfully updated.";
            header("Location:game_records.php");
            exit;
        }
    } else {
        $_POST['date'] = date("Y-m-d", strtotime($_POST['date']));
        $where = "game_id = " . $_POST['game_id'] . " and date = '" . $_POST['date'] . "'  and id <> $id";
        $check = $con->select('games_records', '*', $where);
        if (count($check) > 0) {
            $_SESSION["msg"] = "Record already exists for this Game and Date";
        } else {
            $where = 'id=' . $id;
            unset($_POST['menuno']);
            $res = $con->update('games_records', $_POST, $where);
            if ($res) {
                $_SESSION["msg"] = "Successfully updated.";
            } else {
                $_SESSION["msg"] = "Updation Failed Please Try Again";
            }
        }
        header("Location:game_records.php");
        exit;
    }
}

if (isset($_REQUEST['group_record'])) {
    $id = $_REQUEST['group_record'];
    $where = "id = $id";
    $r = $con->select('games_records', '*', $where);
    $ret = $r[0];
}


$active = 'game_records';
$datepicker = 'true';
  
?>











   
<html lang="en">
  <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        	<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
        <title>Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
 

    </head>
       <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
             
       <main>
                    <div class="container-fluid px-4">
                        

                       
                        <div class="card mb-4">
                            
 
<h3 class="col-md-offset-1">Select Game</h3>
<div class="base col-md-6 col-md-offset-1">
 <form method="post" action="game_records.php<?php echo (isset($id)) ? '?group_record=' . $id : '' ?>" id="form">
        <p style="color:#F00;" id="mesg">
            <?php
            echo (isset($_SESSION["msg"])) ? $_SESSION["msg"] : '';
            unset($_SESSION["msg"]);
            ?>
        </p>
        <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">Game Name</label>
            <div class="col-sm-9">
                <select class="form-control" id="game_id" name="game_id" required="required">
                    <option value="">Select Game</option>
                    <?php
                    $arr = $con->select('games', 'id,name');
                    foreach ($arr as $key => $value) {
                        $sel = '';
                        if (isset($_REQUEST['game'])) {
                            if ($value['id'] === $_REQUEST['game']) {
                                $sel = 'selected="selected"';
                            }
                        }
                        if (isset($ret['game_id'])) {
                            if ($value['id'] === $ret['game_id']) {
                                $sel = 'selected="selected"';
                            }
                        }
                        ?>
                        <option value="<?= $value['id']; ?>" <?php echo (isset($sel)) ? $sel : ''; ?>><?= $value['name']; ?></option>
                    <?php }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="example-search-input" class="col-sm-3 col-form-label">Result</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo (isset($ret['result'])) ? $ret['result'] : ''; ?>" id="result" name="result" placeholder="" required="required"/>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3">Date</label>
            <div class="col-sm-9">
                <input class="form-control" type="date" value="<?php echo (isset($ret['date'])) ? date("d-m-Y", strtotime($ret['date'])) : ''; ?>" id="date" name="date" placeholder="" required="required" autocomplete="off"/>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-10 col-sm-offset-10">
                <button type="submit" class="btn btn-primary" name="btnsubmit" id="save" onclick="check();">Save</button>
            </div>
        </div>
    </form>
</div>
<div class="clearfix"></div> 
 
<div class="clearfix"></div> 
<div class="col-md-10 col-md-offset-1">
    <h3>Games Result List</h3>
 <table class="table table-bordered table-condensed table-responsive table-striped table-hover col-md-8">
        <tr>
            <th>S.No</th>
            <th>Game Name</th>
            <th>Opening Time</th>
            <th>Date</th>
            <th>Result</th>

            <th colspan="2">Action</th>
        </tr>
        <?php
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        $game_no = $con->select('games', 'id');
//        $perpage = 2;
        $perpage = count($game_no);

        $count_no = $conn->query("select g.name,gr.id,gr.result,gr.date,g.is_admin_game,g.open_time from games_records gr inner join games g on gr.game_id = g.id order by gr.date desc");
        $no = $count_no->num_rows;
        $offset = ($page - 1) * $perpage;

        $limit = "limit $offset, $perpage";
        $i = 0;
        $total_page = ceil($no / $perpage);
//        echo "select g.name,gr.id,gr.result,gr.date,g.is_admin_game,g.open_time from games_records gr inner join games g on gr.game_id = g.id order by gr.date desc $limit";
        $rt = $conn->query("select g.name,gr.id,gr.result,gr.date,g.is_admin_game,g.open_time from games_records gr inner join games g on gr.game_id = g.id order by gr.date desc $limit");
        while ($row = $rt->fetch_assoc()) {
            $i++;
            ?>
            <tr>
                <td><?php echo $i + $offset; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo date("g:i a", strtotime($row['open_time'])); ?></td>
                <td><?php echo date("d-m-Y", strtotime($row['date'])); ?></td>
                <td><?php echo $row['result']; ?></td>
                <td>
                    <a href="game_records.php?group_record=<?php echo $row['id']; ?>">Edit</a>
                </td>
                <td>
                    <a href="game_records.php?group_record=<?php echo $row['id'] ?>&mode=delete" class="inner-link" onclick="return confirmDelete();">Delete</a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
    
     <div style="overflow-x: scroll;">
        <ul class="pagination pagination-sm">
            <?php
            if ($total_page > 1):
                for ($x = 1; $x <= $total_page; $x++) {
                    ?>
                    <li style="padding-left:10px;" class="<?= ($page == $x) ? 'disabled active' : ''; ?>" ><a href="<?php echo $_SERVER['PHP_SELF'] . '?page=' . $x ?>"><?= $x; ?></a></li>
                <?php
                }
            endif;
            ?>
        </ul>
    </div>
</div>

<script type="text/javascript">
    function confirmDelete()
    {
        var agree = confirm("Are you sure you want to delete?");
        if (agree)
            return true;
        else
            return false;
    }
      $('document').ready(function () {
        $('#close_time').attr('disabled');
        if ($('#is_matka').is(':checked') === true) {
            $('#close_time').prop("disabled", false);

        } else {
            $('#close_time').prop("disabled", true);
        }
        $('#is_matka').on('change', function (e) {
            if (e.target.checked) {
                $('#close_time').prop("disabled", false);
            } else {
                $('#close_time').prop("disabled", true);

            }
        });

    });
</script>

	    </div>


                    </div>
                </main>
          <?php include('../includes/footer.php');?>
            </div>
        </div>
      
      
       
            </div>
        </div>
        
        
    <?php    } ?>