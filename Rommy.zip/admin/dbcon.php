<?php

define('DB_SERVER', 'localhost');
define('DB_USER', 'u856155168_sbsattak_userd');
define('DB_PASS', 'Admin@123Admin@123Admin@123Admin@123');
define('DB_NAME', 'u856155168_sbsattak_dtdel');


 
 
class DB_con {

    private $conn; 

    function __construct() {
        $this->conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS) or die('localhost connection problem' . mysqli_error());
        mysqli_select_db($this->conn, DB_NAME);
    }

    public function insert($table, array $values) {
        $column = implode(",", array_keys($values));        
        $value = "'" . implode("','", array_values($values)) . "'";
        $res = $this->conn->query("INSERT INTO $table ($column) VALUES($value)");
        return $res;
    }

    public function update($table, array $values, $where) {

        foreach ($values as $key => $value) {
            $val[] = $key . " = " . "'" . $value . "'";
        }
        $update_val = implode(',', $val);
        // echo "Update $table set $update_val where $where";
        // exit;
        $res = $this->conn->query("Update $table set $update_val where $where");
        return $res;
    }

    public function select($table, $col, $where = 1) {
    //    echo "SELECT $col FROM $table where $where";
        $res = $this->conn->query("SELECT $col FROM $table where $where");             
        $array =array();        
        if ($res->num_rows > 0) {

            while ($data = $res->fetch_assoc()) {
                $array[] = $data;
            }
            return $array;
        }else{
            // echo count($array);
            return $array;
        }

    }
    public function select_join($table1,$table2,$col, $join, $condition) {
        $res = $this->conn->query("SELECT $col FROM $table1 $join $table2 on $condition");
        $array =array();
        if ($res->num_rows > 0) {
            while ($data = $res->fetch_assoc()) {
                $array[] = $data;
            }
            return $array;
        }else{
            return $array;
        }
    }

    public function delete($table, $where) {
        $res = $this->conn->query("DELETE FROM $table where $where");
        return $res;
    }
    

}

?>