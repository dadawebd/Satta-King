<?php 
date_default_timezone_set('Asia/Calcutta');
session_start();
 
ini_set('display_errors', 1);
error_reporting(E_ERROR);


 
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
  
    
 include_once 'dbcon.php';
$con = new DB_con();

$id = (isset($_GET['game'])) ? intval($_GET['game']) : '';
if (isset($_GET["mode"]) && $_GET["mode"] == "delete") {
    if ($id > 0) {
        $res = $con->delete('games', 'id=' . $id);
        if ($res) {
            $_SESSION["msg"] = "Successfully deleted.";
        } else {
            $_SESSION["msg"] = "Not deleted.Please Try Again";
        }
        header("Location:game.php");
        exit;
    }
}
if (isset($_POST['btnsubmit'])) {
    $fname = $_FILES['image']['name'];
    if ($_FILES['image']['name'] != "") {
        // Checking filesize
        if ($_FILES['image']['size'] > 1048576) {
            die("The file is too big. Max size is 1MB");
        }
        $rawBaseName = pathinfo($fname, PATHINFO_FILENAME);
        $extension = pathinfo($fname, PATHINFO_EXTENSION);
        $counter = 0;
        while (file_exists("../images/" . $fname)) {
            $fname = $rawBaseName . $counter . '.' . $extension;
            $counter++;
        }
        move_uploaded_file($_FILES['image']['tmp_name'], "../images/" . $fname);
    }

    $path = "images/" . $fname;
    if (isset($path)) {
        $_POST['image_path'] = ($path === "images/") ? '' : $path;
    }
    unset($_POST['btnsubmit']);
    $open_time = $_POST['open_time'];
    $tme = explode(' ', $open_time);
    if (strtolower(trim($tme[1])) === 'pm') {
        $tme1 = explode(':', $tme[0]);
        $tme1_1 = (($tme1[0] + 12) <= 24) ? ($tme1[0] + 12) : $tme1[0];
        $open_time_val = $tme1_1 . ':' . $tme1[1] . ':00';
    } else {
        $open_time_val = $tme[0] . ':00';
    }

    $_POST['open_time'] = ($open_time_val == '24:00:00') ? '00:00:00' : $open_time_val;
    if (isset($_POST['is_admin_game']) && $_POST['is_admin_game'] == 1) {
        $val['is_admin_game'] = 0;
        $res = $con->update('games', $val, 1);
    }
    if ($id <= 0) {
         
        $res = $con->insert('games', $_POST);
         if ($res) {
            $_SESSION["msg"] = "Successfully  Insert .";
        } else {
            $_SESSION["msg"] = "Not Insert Please Try Again";
        }
        header("Location:game.php");
        exit;
    } else {
        $where = 'id=' . $id;
        unset($_POST['menuno']);
        $res = $con->update('games', $_POST, $where);
        if ($res) {
            $_SESSION["msg"] = "Successfully updated.";
        } else {
            $_SESSION["msg"] = "Updation Failed Please Try Again";
        }
        header("Location:game.php");
        exit;
    }
}
if ($_REQUEST['game']) {
    $id = $_REQUEST['game'];
    $where = 'id = ' . $id;
    $r = $con->select('games', '*', $where);
    $ret = $r[0];
}

$active = 'game';
 
?>











   
<html lang="en">
  <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        	<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
        <title>Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
 

    </head>
       <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
             
       <main>
                    <div class="container-fluid px-4">
                        

                       
                        <div class="card mb-4">
                            
 
<h3 class="col-md-offset-1"><?= ($id) ? 'Update' : 'Add' ?> Game</h3>
<div class="base col-md-6 col-md-offset-1">
    <form method="post"  enctype="multipart/form-data">
        <p style="color:#F00;"><?php
            echo $_SESSION["msg"];
            unset($_SESSION["msg"])
            ?></p>
        <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">Game Name</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['name']) ? $ret['name'] : ''; ?>" id="name" name="name" placeholder="Enter Game Name" required="required"/>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Open Time</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['open_time']) ? date("g:i a", strtotime($ret['open_time'])) : ''; ?>" id="open_time" name="open_time" placeholder="hh:mm am" required="required"/>
            </div>
        </div>
         
<!--        <div class="form-group row">
            <label class="col-sm-3">Admin Game</label>
            <div class="col-sm-9">
                <div class="form-check">
                    <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" name="is_admin_game" value="1" <?= (isset($ret['is_admin_game']) && $ret['is_admin_game'] == 1) ? 'checked="checked"' : '' ?>> Check me for Admin Game
                    </label>
                </div>
            </div>
        </div>-->
        <div class="form-group row">
            <label class="col-sm-3">Matka Game</label>
            <div class="col-sm-9">
                <div class="form-check">
                    <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" id="is_matka" name="is_matka" value="1" <?= (isset($ret['is_matka']) && $ret['is_matka'] == 1) ? 'checked="checked"' : '' ?>> Check me for included in Matka Game
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group row" id="closeTime">
            <label class="col-sm-3 col-form-label">Close Time</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['close_time']) ? date("g:i a", strtotime($ret['close_time'])) : ''; ?>" id="close_time" name="close_time" placeholder="hh:mm am" required="required" />
            </div>
        </div>
        
        
       
         <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">background-color</label>
            <div class="col-sm-9">
                <input class="form-control" id="name" name="background" placeholder="Enter Color Name" type="text" value="<?php echo $ret['background'] ? $ret['background'] : ''; ?>"  />
            </div>
        </div>
        
         <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">Full Line / Half Line</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['coln']) ? $ret['coln'] : ''; ?>" id="name" name="coln" placeholder="Lambi line ke liye 12 or aadhi line ke liye 6" />
            </div>
        </div>
        
        
          <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">new-color</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['newcolr']) ? $ret['newcolr'] : ''; ?>" id="name" name="newcolr" placeholder="Enter Color New Result Color" />
            </div>
        </div>
        
          <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">old-color</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['oldcolr']) ? $ret['oldcolr'] : ''; ?>" id="name" name="oldcolr" placeholder="Enter Color Old Result" />
            </div>
        </div>
        
           <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">time-color</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['timecolr']) ? $ret['timecolr'] : ''; ?>" id="name" name="timecolr" placeholder="Enter Color time color" />
            </div>
        </div>
        
        
          <div class="form-group row">
            <label for="example-text-input" class="col-sm-3 col-form-label">Game color</label>
            <div class="col-sm-9">
                <input class="form-control" type="text" value="<?php echo ($ret['gamecolr']) ? $ret['gamecolr'] : ''; ?>" id="name" name="gamecolr" placeholder="Enter Color time color" />
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-10 col-sm-offset-10">
                <button type="submit" class="btn btn-primary" name="btnsubmit">Save</button>
            </div>
        </div>
    </form>
</div>
<div class="clearfix"></div> 
 
<div class="clearfix"></div> 
<div class="col-md-10 col-md-offset-1">
    <h3>Games List</h3>
    <table class="table table-bordered table-condensed table-responsive table-striped table-hover col-md-8">
        <tr>
            <th>S.No</th>
            <th>Name</th>
            <th>Opening Time</th>
            <th>Close Time</th>
            <th>Matka Game</th>
            <th>Color</th>
             <th>Full Line/ Half Line</th>
            <th colspan="2">Action</th>
        </tr>
        <?php
        $rt = $con->select('games', '*');
        $i = 0;
        foreach ($rt as $key => $value) {
            $i++;
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $value['name']; ?></td>
                <td><?php echo date("g:i a", strtotime($value['open_time'])); ?></td>
                <td><?php echo ($value['is_matka'] == 0) ? '-' : date("g:i a", strtotime($value['close_time'])); ?></td>
                <td><?php echo ($value['is_matka'] == 0) ? '' : 'Matka'; ?></td>
                <td><?php echo ($value['background']) ? $value['background'] : 'White'; ?></td>
                   <td><?php echo ($value['coln']) ? $value['coln'] : '6'; ?></td>
                
                <td>
                    <a href="game.php?game=<?php echo $value['id']; ?>">Edit</a>
                </td>
                <td>
                    <a href="game.php?game=<?php echo $value['id'] ?>&mode=delete" class="inner-link" onclick="return confirmDelete();">Delete</a>
                </td>
<!--                <td>
                    <a href="game_records.php?game=<?php echo $value['id'] ?>" class="inner-link" >Update Result</a>
                </td>-->
            </tr>
            <?php
        }
        ?>
    </table>
</div>

<script type="text/javascript">
    function confirmDelete()
    {
        var agree = confirm("Are you sure you want to delete?");
        if (agree)
            return true;
        else
            return false;
    }
      $('document').ready(function () {
        $('#close_time').attr('disabled');
        if ($('#is_matka').is(':checked') === true) {
            $('#close_time').prop("disabled", false);

        } else {
            $('#close_time').prop("disabled", true);
        }
        $('#is_matka').on('change', function (e) {
            if (e.target.checked) {
                $('#close_time').prop("disabled", false);
            } else {
                $('#close_time').prop("disabled", true);

            }
        });

    });
</script>

	    </div>


                    </div>
                </main>
          <?php include('../includes/footer.php');?>
            </div>
        </div>
      
      
       
            </div>
        </div>
        
        
    <?php    } ?>