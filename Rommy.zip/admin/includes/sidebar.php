  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            
                             <a class="nav-link" href="/signup.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                               Create user
                            </a>
                 
                            <a class="nav-link" href="manage-users.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Manage Users
                            </a>

 <a class="nav-link" href="bwdates-report-ds.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-calendar"></i></div>
                                B/w Dates Report
                            </a>
                            
                            
                            
                             <a class="nav-link" href="Keywords.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-braille"></i></div>
                                Keywords
                            </a>
                               
                             <a class="nav-link" href="Addwhatsp.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-barcode"></i></div>
                                Whatsup Section
                            </a>
                            
                            
                             <a class="nav-link" href="Editwhatsp.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-bullseye"></i></div>
                               Edit  Whatsup Sec.
                            </a>


  <a class="nav-link" href="Addcall.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-phone"></i></div>
                                Call Section
                            </a>
                            
                            
                             <a class="nav-link" href="Editcall.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-edit"></i></div>
                               Edit  Call Sec.
                            </a>
                            
                            
                               <a class="nav-link" href="game.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-edit"></i></div>
                              Add Game
                            </a>
                            
                            
                             <a class="nav-link" href="game_records.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-edit"></i></div>
                              Add Result
                            </a>

                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Signout
                            </a>
                            
                            
                            
                        </div>
                    </div>
                
                </nav>
            </div>