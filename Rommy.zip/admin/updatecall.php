<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
  
 if(isset($_POST['update']))
{
    
       $ids=$_GET['id'];
$background=$_POST['background'];
            $wtsnumber=$_POST['wtsnumber'];
               $contents=$_POST['contents'];
     
        
                mysqli_set_charset($con,'utf8mb4');

        
         
        
        
              
              
           
              
              
              
              
            
                    
            
                        
  $sql="UPDATE addcallssection SET background='$background',wtsnumber='$wtsnumber',contents='$contents' WHERE id='$ids'";
$res=mysqli_query($con,$sql);
$msg="updated successfully";
              
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        	<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
        <title>Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
 

    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        

                        <h1 class="mt-4">
Update
</h1>
                        <div class="card mb-4">
                            
                            			    
			    
			   
			   
			   <?php
			     
			     $ids=$_GET['id'];
$sql=" SELECT id,background,wtsnumber,contents FROM addcallssection WHERE id='$ids'";
mysqli_set_charset($con,'utf8');
$res=mysqli_query($con,$sql);
 
if(mysqli_num_rows($res)>0)
{
    while ($row=mysqli_fetch_assoc($res))
     {
           
        $background=$row['background'];
        $wtsnumber=$row['wtsnumber'];
        
        
         $contents =$row['contents'];
        
        
        
        
    
        
        
        
        
    }
    
    
}

 
 
   

 
?>
			
 


                      <form role="form" method="post">
                        
                        
                          <?php 
                     if($error)
                        {
                        ?>
                        <div class="errorWrap"><strong>ERROR</strong>:
                            <?php echo $error; ?> 
                        </div>
                      <?php 
                      } 
                else if($msg)
                     {
                    ?>
                    <div class="succWrap"><strong>SUCCESS</strong>:
                        <?php echo $msg; ?> 
                        </div>
                    <?php 
                }
                ?>
                    	 
				 	
			 <table class="table table-striped"  style="width: 100%;text-align: center;" width="auto" cellspacing="0" cellpadding="4" border="1" bgcolor="white">
          <thead>
          <tr>
                                                       
                                                       
                                                          <th>Background Color</th>
                                                          <th>Whatsup number</th>
                                                         
                                                          
                                              <th>Content</t
                                                             
                                                       
                                                           
                                                           
												    </tr>
                                               </thead>
                                               <tbody> 




    
                
 
    
                <tr>

            
             
            
                               <td style="width:200px;" ><font size="5">	<input class="form-control" type="text" name="background" value="<?php echo $background;?>"  style="width:100%;" ></font></td>
            
            <td style="width:200px;" ><font size="5">	<input class="form-control" type="text" name="wtsnumber" value="<?php echo  $wtsnumber;?>"  style="width:100%;" ></font></td>
            
            
        
         
                                         <td style="width:200px;"  >  <textarea name="contents" cols="15" rows="15"><?php echo $contents;?></textarea><br>   </td>
            
           
         <script>
                        CKEDITOR.replace( 'contents' );
                </script>
            
            
        
        
            
         
            
            
            
            
              
          
            
            
        
        
       
            
            
          
            
            
            
           
            
         
            
            </tr>
             
           

            
 
     </tbody>
     </table>
                  
					<br>							    
												    
  
							
							
								
						</div>
					</div>
						<div class="col-md-4">										
								<div class="form-group has-success">
									<button type="submit" class="btn btn-primary btn-block" name="update" style="font-weight: bold;">Update </button>
								</div>	
						</div>
					 
					 
							
							</form>

						
    
                  
					    </div>


                    </div>
                </main>
          <?php include('../includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
