 <?php
  
 error_reporting(0);
 include_once('../includes/config.php');
 if(isset($_GET['id']))
 {
     
     $id=$_GET['id'];
     $sql="DELETE FROM addwtssection where id='$id'";
      $re=mysqli_query($con,$sql);
      
      if($re)
      {
       
      
         
  require_once('Editwhatsp.php');
  
   
      }
       else
 {
     echo "failed";
 }
      
 }

 ?>